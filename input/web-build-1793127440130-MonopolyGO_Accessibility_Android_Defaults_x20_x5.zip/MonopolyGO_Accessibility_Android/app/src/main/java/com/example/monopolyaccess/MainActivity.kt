package com.example.monopolyaccess

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.database.Cursor
import android.provider.OpenableColumns
import android.view.ViewGroup
import kotlin.math.max

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var targetRange: Spinner
    private lateinit var targetMultiplier: Spinner
    private lateinit var otherMultiplier: Spinner
    private lateinit var auto: Switch
    private lateinit var info: TextView
    private val pickTemplate = 41

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
            gravity = Gravity.TOP
        }
        fun heading(text: String) = TextView(this).apply {
            this.text = text; textSize = 21f; setPadding(0, 8, 0, 12)
        }
        fun body(text: String) = TextView(this).apply {
            this.text = text; textSize = 16f; setPadding(0, 4, 0, 12)
        }

        layout.addView(heading("Railroad Assist"))
        layout.addView(body("Accessibility prototype for Monopoly GO. Defaults: use x20 when a railroad is 6, 7, or 8 spaces away; otherwise use x5. Automatic railroad detection is not implemented yet."))
        val access = Button(this).apply {
            text = "1. Enable Android accessibility service"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        layout.addView(access)

        layout.addView(body("2. Choose the target distance"))
        targetRange = Spinner(this).also {
            it.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("6 spaces", "7 spaces", "8 spaces", "Any of 6, 7, or 8").also { /* default target is the final option */ })
            it.setSelection(3) // Default: any of 6, 7, or 8 spaces
            layout.addView(it)
        }

        val multiplierOptions = listOf("x1", "x2", "x3", "x5", "x10", "x20", "x50", "x100")
        layout.addView(body("3. Multiplier when a railroad is 6, 7, or 8 spaces away"))
        targetMultiplier = Spinner(this).also {
            it.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, multiplierOptions)
            it.setSelection(multiplierOptions.indexOf("x20"))
            layout.addView(it)
        }
        layout.addView(body("4. Multiplier when no railroad is 6, 7, or 8 spaces away"))
        otherMultiplier = Spinner(this).also {
            it.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, multiplierOptions)
            it.setSelection(multiplierOptions.indexOf("x5"))
            layout.addView(it)
        }

        auto = Switch(this).apply {
            text = "Allow automatic multiplier tap"
            textSize = 17f
            isChecked = false
        }
        layout.addView(auto)
        layout.addView(Button(this).apply {
            text = "Show / hide transparent board overlay"
            setOnClickListener {
                val svc = GameAccessibilityService.instance
                if (svc == null) status.text = "Enable the accessibility service first."
                else {
                    svc.toggleBoardOverlay()
                    status.text = "Board guide toggled. Drag the guide to align it; use + / − to resize. This is a calibration guide, not automatic detection yet."
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "Capture current game screen"
            setOnClickListener {
                val svc = GameAccessibilityService.instance
                if (svc == null) {
                    status.text = "Enable Railroad Assist in Android Accessibility settings first."
                } else {
                    svc.captureScreen { bitmap ->
                        runOnUiThread {
                            if (bitmap == null) status.text = "Screenshot failed. Try again while the game is visible."
                            else {
                                GameAccessibilityService.lastScreenWidth = bitmap.width
                                GameAccessibilityService.lastScreenHeight = bitmap.height
                                status.text = "Captured ${bitmap.width} × ${bitmap.height}. This prototype still needs tile positions calibrated."
                            }
                        }
                    }
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "Choose railroad reference image"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE)
                }
                startActivityForResult(intent, pickTemplate)
            }
        })
        layout.addView(Button(this).apply {
            text = "Arm automatic adjustment"
            setOnClickListener {
                val svc = GameAccessibilityService.instance
                if (svc == null) {
                    status.text = "Enable the accessibility service first."
                } else if (!auto.isChecked) {
                    status.text = "Turn on 'Allow automatic multiplier tap' first."
                } else {
                    val chosen = targetMultiplier.selectedItem.toString()
                    val fallback = otherMultiplier.selectedItem.toString()
                    svc.arm(chosen)
                    status.text = "Settings selected: $chosen for railroad distances 6/7/8; $fallback otherwise. These are saved only for this screen session. Automatic detection and switching are not implemented yet."
                }
            }
        })
        status = body("Status: accessibility service not checked.")
        layout.addView(status)
        info = body("Privacy: screen inspection is local to this device in this prototype. No account login or game credentials are requested.")
        layout.addView(info)
        layout.addView(body("Important: Android can restrict interaction with other apps. Test only with the game visible, and disarm immediately if taps are inaccurate."))
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickTemplate && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                try {
                    contentResolver.openInputStream(uri)?.use { input ->
                        val bmp = BitmapFactory.decodeStream(input)
                        info.text = "Railroad reference image loaded (${bmp?.width ?: 0} × ${bmp?.height ?: 0}). Image matching is a planned next step; loading alone does not enable detection."
                    }
                } catch (_: Exception) {
                    info.text = "Could not read that image. Please choose a normal PNG or JPG image."
                }
            }
        }
    }
}
