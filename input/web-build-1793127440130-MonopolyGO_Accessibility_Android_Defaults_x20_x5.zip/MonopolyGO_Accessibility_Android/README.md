# Railroad Assist — Android prototype

This is an Android Studio starter project for an accessibility helper for Monopoly GO.

## What is implemented
- Android Accessibility Service setup, with screenshot capability (Android 11 / API 30+).
- UI for selecting a target distance (6, 7, 8) and a multiplier label.
- A screen-capture test and a railroad reference-image picker.
- A gated accessibility gesture helper for future calibrated taps.

## What is NOT implemented yet
**This is not a finished, working automatic railroad detector.** It does not yet identify the player's token or railroad tiles, calculate their route distance from a live board image, or automatically change the game's multiplier. The reference image picker currently only loads and reports the image dimensions. Those features require a board-specific image-matching/calibration pipeline and real-device testing.

The multiplier button coordinates and exact board tile sequence can vary with device resolution, UI layout, events, and game updates. It would be unsafe to tap guessed coordinates automatically. The current project therefore does not trigger a tap based on a false detection.

## Build
1. Open this folder in Android Studio (recent version with Android Gradle Plugin 8.7.3 support).
2. Let Gradle sync and install on an Android 11+ device.
3. Enable **Railroad Assist controls** in Android Settings → Accessibility.
4. Open Monopoly GO and use **Capture current game screen** to verify screenshot access.

## Next implementation steps
1. Add a guided calibration overlay so the user marks the token, tile centers in board order, and multiplier control locations.
2. Add image matching for railroad tiles using user-provided reference crops and confidence thresholds.
3. Calculate clockwise distance along the calibrated tile sequence and accept only 6, 7, or 8 spaces.
4. Add a preview/confirmation stage, then optional automatic tap after repeated correct detections.
5. Test on the user's actual device and game version; include a prominent disarm control.

## Safety and privacy
- No login credentials are requested.
- Screenshots are processed on-device in this prototype.
- Android Accessibility permission is powerful. Enable it only if you understand and trust the app, and disable it in system settings when not in use.
- Game updates or board animations can invalidate calibration. Keep automatic taps disabled until detection has been validated.


Requested default multiplier settings (UI only): target distances are any of 6, 7, or 8 spaces; use x20 for those distances and x5 otherwise. Automatic railroad recognition and multiplier switching are not implemented in this prototype.
