package com.example.monopolyaccess

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.accessibilityservice.GestureDescription
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.min

class GameAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: GameAccessibilityService? = null
        @Volatile var lastScreenWidth: Int = 0
        @Volatile var lastScreenHeight: Int = 0
    }
    @Volatile private var armedMultiplier: String? = null
    private var overlay: BoardGuideView? = null
    private var controlsOverlay: LinearLayout? = null
    private var guide: BoardGuideView? = null
    private lateinit var wm: WindowManager

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* No game actions on unsolicited events. */ }
    override fun onInterrupt() { armedMultiplier = null }
    override fun onDestroy() {
        hideBoardOverlay()
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun arm(multiplier: String) { armedMultiplier = multiplier }
    fun disarm() { armedMultiplier = null }

    fun toggleBoardOverlay() { if (overlay == null) showBoardOverlay() else hideBoardOverlay() }

    private fun showBoardOverlay() {
        if (overlay != null) return
        val board = BoardGuideView(this)
        guide = board
        // The drawing window is explicitly NOT_TOUCHABLE, so taps anywhere on the game
        // and Android navigation/system UI pass through to the app underneath.
        val boardLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            android.graphics.PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(board, boardLp)
            overlay = board
        } catch (_: Exception) {
            overlay = null; guide = null; return
        }

        // Only this compact control strip receives touches. The rest of the screen
        // remains fully interactive. Alignment uses arrow buttons because a full-screen
        // draggable window would intercept taps intended for Monopoly GO.
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(6, 6, 6, 6)
            setBackgroundColor(0xDD101820.toInt())
        }
        fun row(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        fun control(parent: LinearLayout, label: String, action: () -> Unit) {
            parent.addView(Button(this).apply {
                text = label
                textSize = 17f
                minWidth = 52
                minHeight = 48
                setPadding(8, 4, 8, 4)
                setOnClickListener { action() }
            }, LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        val moveRow = row()
        control(moveRow, "←") { board.moveBy(-18f, 0f) }
        control(moveRow, "↑") { board.moveBy(0f, -18f) }
        control(moveRow, "↓") { board.moveBy(0f, 18f) }
        control(moveRow, "→") { board.moveBy(18f, 0f) }
        controls.addView(moveRow)
        val sizeRow = row()
        control(sizeRow, "SIZE −") { board.zoomBy(0.85f) }
        control(sizeRow, "SIZE +") { board.zoomBy(1.18f) }
        control(sizeRow, "RESET") { board.resetGuide() }
        control(sizeRow, "HIDE") { hideBoardOverlay() }
        controls.addView(sizeRow)
        val controlsLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL }
        try {
            wm.addView(controls, controlsLp)
            controlsOverlay = controls
        } catch (_: Exception) {
            try { wm.removeView(board) } catch (_: Exception) {}
            overlay = null; guide = null; controlsOverlay = null
        }
    }

    private fun hideBoardOverlay() {
        controlsOverlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        controlsOverlay = null; overlay = null; guide = null
    }

    fun captureScreen(callback: (Bitmap?) -> Unit) {
        if (android.os.Build.VERSION.SDK_INT < 30) { callback(null); return }
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(screenshot: ScreenshotResult) {
                val hardware = screenshot.hardwareBuffer
                val bitmap = Bitmap.wrapHardwareBuffer(hardware, screenshot.colorSpace)
                val copy = bitmap?.copy(Bitmap.Config.ARGB_8888, false)
                hardware.close()
                callback(copy)
            }
            override fun onFailure(errorCode: Int) { callback(null) }
        })
    }

    // Gesture primitive retained for a future explicitly calibrated multiplier tap.
    fun tapAt(x: Float, y: Float, done: (Boolean) -> Unit = {}) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
            .build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { done(true) }
            override fun onCancelled(gestureDescription: GestureDescription?) { done(false) }
        }, Handler(Looper.getMainLooper()))
    }

    private class BoardGuideView(context: android.content.Context) : View(context) {
        private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFEA00.toInt(); style = Paint.Style.STROKE; strokeWidth = 4f }
        private val rail = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF7043.toInt(); style = Paint.Style.FILL }
        private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 25f; textAlign = Paint.Align.CENTER; setShadowLayer(3f, 1f, 1f, Color.BLACK) }
        private var cx = 0f; private var cy = 0f; private var scale = 0.78f
        private var lastX = 0f; private var lastY = 0f
        fun zoomBy(f: Float) { scale = (scale * f).coerceIn(0.25f, 1.65f); invalidate() }
        fun moveBy(dx: Float, dy: Float) { if (cx == 0f) { cx = width / 2f; cy = height / 2f }; cx += dx; cy += dy; invalidate() }
        fun resetGuide() { cx = width / 2f; cy = height / 2f; scale = 0.78f; invalidate() }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            if (cx == 0f) { cx = width / 2f; cy = height / 2f }
            val halfW = min(width * 0.43f, height * 0.43f) * scale
            val halfH = halfW * 0.92f
            val top = floatArrayOf(cx, cy-halfH)
            val right = floatArrayOf(cx+halfW, cy)
            val bottom = floatArrayOf(cx, cy+halfH)
            val left = floatArrayOf(cx-halfW, cy)
            val diamond = Path().apply { moveTo(top[0],top[1]); lineTo(right[0],right[1]); lineTo(bottom[0],bottom[1]); lineTo(left[0],left[1]); close() }
            canvas.drawPath(diamond, line)
            // Each side represents ten spaces. The orange circles mark approximate classic railroad indices.
            val corners = arrayOf(bottom, left, top, right, bottom)
            for (side in 0..3) {
                val a = corners[side]; val b = corners[side+1]
                for (i in 1..9) {
                    val t = i / 10f
                    val x = a[0] + (b[0]-a[0])*t
                    val y = a[1] + (b[1]-a[1])*t
                    canvas.drawCircle(x, y, 4.5f, line)
                }
            }
            // Approximate railroad marker positions, meant for manual alignment only.
            val marks = listOf(0.5f to 0f, 1f to 0.5f, 0.5f to 1f, 0f to 0.5f)
            for ((x,y) in marks) {
                val px = left[0] + (right[0]-left[0])*x
                val py = top[1] + (bottom[1]-top[1])*y
                canvas.drawCircle(px, py, 13f, rail)
            }
            canvas.drawText("ALIGN BOARD • use arrows", cx, (cy-halfH-18).coerceAtLeast(28f), text)
            canvas.drawText("orange = approximate railroad guide", cx, (cy+halfH+32).coerceAtMost(height-12f), text)
        }

    }
}
