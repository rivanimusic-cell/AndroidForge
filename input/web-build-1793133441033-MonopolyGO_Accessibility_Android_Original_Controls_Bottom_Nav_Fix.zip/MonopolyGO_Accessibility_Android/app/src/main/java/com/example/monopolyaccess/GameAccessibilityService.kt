package com.example.monopolyaccess

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.accessibilityservice.GestureDescription
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.min

class GameAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: GameAccessibilityService? = null
        @Volatile var lastScreenWidth: Int = 0
        @Volatile var lastScreenHeight: Int = 0
    }
    @Volatile private var armedMultiplier: String? = null
    private var overlay: FrameLayout? = null
    private var guide: BoardGuideView? = null
    private lateinit var wm: WindowManager

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* No game actions on unsolicited events. */ }
    override fun onInterrupt() { armedMultiplier = null }
    override fun onDestroy() {
        hideBoardOverlay()
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun arm(multiplier: String) { armedMultiplier = multiplier }
    fun disarm() { armedMultiplier = null }

    fun toggleBoardOverlay() { if (overlay == null) showBoardOverlay() else hideBoardOverlay() }

    private fun showBoardOverlay() {
        if (overlay != null) return
        val root = FrameLayout(this)
        val board = BoardGuideView(this)
        guide = board
        root.addView(board, FrameLayout.LayoutParams(-1, -1))
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 8, 8, 8)
            setBackgroundColor(0xAA101820.toInt())
        }
        fun control(label: String, action: () -> Unit) {
            controls.addView(Button(this).apply {
                text = label
                setOnClickListener { action() }
            }, LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.WRAP_CONTENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        control("−") { board.zoomBy(0.85f) }
        control("+") { board.zoomBy(1.18f) }
        control("↻") { board.resetGuide() }
        control("×") { hideBoardOverlay() }
        val cp = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        root.addView(controls, cp)
        // Keep the original large, readable controls and draggable/resizable guide, but stop
        // the touchable overlay above Android's bottom navigation area so Home/Recents remain usable.
        val bottomNavSafeHeight = resources.displayMetrics.heightPixels - (64 * resources.displayMetrics.density).toInt()
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            bottomNavSafeHeight.coerceAtLeast(1),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            android.graphics.PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(root, lp)
            overlay = root
        } catch (_: Exception) {
            overlay = null; guide = null
        }
    }

    private fun hideBoardOverlay() {
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        overlay = null; guide = null
    }

    fun captureScreen(callback: (Bitmap?) -> Unit) {
        if (android.os.Build.VERSION.SDK_INT < 30) { callback(null); return }
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(screenshot: ScreenshotResult) {
                val hardware = screenshot.hardwareBuffer
                val bitmap = Bitmap.wrapHardwareBuffer(hardware, screenshot.colorSpace)
                val copy = bitmap?.copy(Bitmap.Config.ARGB_8888, false)
                hardware.close()
                callback(copy)
            }
            override fun onFailure(errorCode: Int) { callback(null) }
        })
    }

    // Gesture primitive retained for a future explicitly calibrated multiplier tap.
    fun tapAt(x: Float, y: Float, done: (Boolean) -> Unit = {}) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
            .build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { done(true) }
            override fun onCancelled(gestureDescription: GestureDescription?) { done(false) }
        }, Handler(Looper.getMainLooper()))
    }

    private class BoardGuideView(context: android.content.Context) : View(context) {
        private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFEA00.toInt(); style = Paint.Style.STROKE; strokeWidth = 4f }
        private val rail = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF7043.toInt(); style = Paint.Style.FILL }
        private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 25f; textAlign = Paint.Align.CENTER; setShadowLayer(3f, 1f, 1f, Color.BLACK) }
        private var cx = 0f; private var cy = 0f; private var scale = 0.78f
        private var lastX = 0f; private var lastY = 0f
        fun zoomBy(f: Float) { scale = (scale * f).coerceIn(0.35f, 1.5f); invalidate() }
        fun resetGuide() { cx = width / 2f; cy = height / 2f; scale = 0.78f; invalidate() }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            if (cx == 0f) { cx = width / 2f; cy = height / 2f }
            val halfW = min(width * 0.43f, height * 0.43f) * scale
            val halfH = halfW * 0.92f
            val top = floatArrayOf(cx, cy-halfH)
            val right = floatArrayOf(cx+halfW, cy)
            val bottom = floatArrayOf(cx, cy+halfH)
            val left = floatArrayOf(cx-halfW, cy)
            val diamond = Path().apply { moveTo(top[0],top[1]); lineTo(right[0],right[1]); lineTo(bottom[0],bottom[1]); lineTo(left[0],left[1]); close() }
            canvas.drawPath(diamond, line)
            // Each side represents ten spaces. The orange circles mark approximate classic railroad indices.
            val corners = arrayOf(bottom, left, top, right, bottom)
            for (side in 0..3) {
                val a = corners[side]; val b = corners[side+1]
                for (i in 1..9) {
                    val t = i / 10f
                    val x = a[0] + (b[0]-a[0])*t
                    val y = a[1] + (b[1]-a[1])*t
                    canvas.drawCircle(x, y, 4.5f, line)
                }
            }
            // Approximate railroad marker positions, meant for manual alignment only.
            val marks = listOf(0.5f to 0f, 1f to 0.5f, 0.5f to 1f, 0f to 0.5f)
            for ((x,y) in marks) {
                val px = left[0] + (right[0]-left[0])*x
                val py = top[1] + (bottom[1]-top[1])*y
                canvas.drawCircle(px, py, 13f, rail)
            }
            canvas.drawText("ALIGN BOARD • drag to move", cx, (cy-halfH-18).coerceAtLeast(28f), text)
            canvas.drawText("orange = approximate railroad guide", cx, (cy+halfH+32).coerceAtMost(height-12f), text)
        }
        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { lastX = event.rawX; lastY = event.rawY; return true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX-lastX; val dy = event.rawY-lastY
                    cx += dx; cy += dy; lastX = event.rawX; lastY = event.rawY; invalidate(); return true
                }
                MotionEvent.ACTION_UP -> return true
            }
            return true
        }
    }
}
